package weka.classifiers.bayes;


import weka.core.*;
import weka.classifiers.*;
import weka.filters.unsupervised.attribute.RNDDiscretize;

/**
 * Rigorous Non-Disjoint Discretization for Naive Bayes
 * Submitted to Pattern Recognition
 * Author: Huan Zhang, hzhang@cug.edu.cn
 */

public class RNDD extends Classifier {

	/** The number of class and each attribute value occurs in the dataset */
	private double[][] m_ClassAttCounts;

	/** The number of each class value occurs in the dataset */
	private double[] m_ClassCounts;

	/** The number of values for each attribute in the dataset */
	private int[] m_NumAttValues;

	/** The starting index of each attribute in the dataset */
	private int[] m_StartAttIndex;

	/** The number of values for all attributes in the dataset */
	private int m_TotalAttValues;

	/** The number of classes in the dataset */
	private int m_NumClasses;

	/** The number of attributes including class in the dataset */
	private int m_NumAttributes;

	/** The number of instances in the dataset */
	private int m_NumInstances;

	/** The index of the class attribute in the dataset */
	private int m_ClassIndex;
	
	/** The training instances */
	protected Instances m_Instances;

	/** The discretization filter */
	protected RNDDiscretize m_Disc = null;
	
	private double theta;
	

	/**
	 * Generates the classifier.
	 *
	 * @param instances 
	 *            set of instances serving as training data
	 * @exception Exception
	 *            if the classifier has not been generated successfully
	 */
	public void buildClassifier(Instances instances) throws Exception {

		m_Instances = new Instances(instances);
		if(m_Instances.numInstances()<900){
			theta = 30;
		}
		else{
			theta = (int)Math.sqrt(m_Instances.numInstances());
		}
		
		//Rigorous Non-Disjoint Discretization
		m_Disc = new RNDDiscretize();
		m_Disc.setInputFormat(instances);
		instances = weka.filters.Filter.useFilter(instances, m_Disc);

		// reset variable
		m_NumClasses = instances.numClasses();
		m_ClassIndex = instances.classIndex();
		m_NumAttributes = instances.numAttributes();
		m_NumInstances = instances.numInstances();
		m_TotalAttValues = 0;
		
		// allocate space for attribute reference arrays
		m_StartAttIndex = new int[m_NumAttributes];
		m_NumAttValues = new int[m_NumAttributes];
		
		// set the starting index of each attribute and the number of values for
		// each attribute and the total number of values for all attributes(not
		// including class).
		for (int i = 0; i < m_NumAttributes; i++) {
			if (i != m_ClassIndex) {
				m_StartAttIndex[i] = m_TotalAttValues;
				m_NumAttValues[i] = instances.attribute(i).numValues();
				m_TotalAttValues += m_NumAttValues[i];
			} else {
				m_StartAttIndex[i] = -1;
				m_NumAttValues[i] = m_NumClasses;
			}
		}
		
		// allocate space for counts and frequencies
		m_ClassCounts = new double[m_NumClasses];
		m_ClassAttCounts = new double[m_NumClasses][m_TotalAttValues];
		
		// Calculate the counts
		for (int k = 0; k < m_NumInstances; k++) {
			int classVal = (int) instances.instance(k).classValue();
			m_ClassCounts[classVal]++;
			int[] attIndex = new int[m_NumAttributes];
			for (int i = 0; i < m_NumAttributes; i++) {
				if (i == m_ClassIndex) {
					attIndex[i] = -1;
				} else {
					// skip the missing values
					if(instances.instance(k).isMissing(i)) {
						continue;
					}
					attIndex[i] = m_StartAttIndex[i] + (int) instances.instance(k).value(i);
					m_ClassAttCounts[classVal][attIndex[i]]++;
				}
			}
		}
		
	}

	/**
	 * Calculates the class membership probabilities for the given test instance
	 *
	 * @param instance
	 *            the instance to be classified
	 * @return predicted class probability distribution
	 */
	public double[] distributionForInstance(Instance instance) throws Exception {
		
		//Rigorous Non-Disjoint Discretization
		m_Disc.input(instance);
		instance = m_Disc.output();

		// Definition of local variables
		double[] probs = new double[m_NumClasses];
		// store instance's att values in an int array
		int[] attIndex = new int[m_NumAttributes];
		for (int att = 0; att < m_NumAttributes; att++) {
			if (att == m_ClassIndex)
				attIndex[att] = -1;
			else
				attIndex[att] = m_StartAttIndex[att] + (int) instance.value(att);
		}

		for (int classVal = 0; classVal < m_NumClasses; classVal++) {
			probs[classVal] = (m_ClassCounts[classVal] + 1.0/m_NumClasses) / (m_NumInstances + 1.0);
		}

		// calculate probabilities for each possible class value
		for (int att = 0; att < m_NumAttributes; att++) {

			double max = 0;

			for (int classVal = 0; classVal < m_NumClasses; classVal++) {

				if (attIndex[att] == -1){
					continue;
				}
					
				if (instance.isMissing(att)) {
					continue;
				}

				if(m_Instances.attribute(att).type()==0){
					
					double countMiddle = 0;
					for (int class1 = 0; class1 < m_NumClasses; class1++) {
						countMiddle += m_ClassAttCounts[class1][attIndex[att]];
					}
					
					double attrValueFreq = m_ClassAttCounts[classVal][attIndex[att]];
					
					if(countMiddle<theta){
						
						double thresEachSide = (theta - countMiddle) / 2.0;
						double countLeftAll = 0;
						int movepos = 1;
						
						while(countLeftAll<thresEachSide && (int) instance.value(att) - movepos >= 0){
							
							double countLeft = 0;
							if ((int) instance.value(att) - movepos >= 0) {
								for (int class1 = 0; class1 < m_NumClasses; class1++) {
									countLeft += m_ClassAttCounts[class1][attIndex[att] - movepos];
								}
							}
							
							if(countLeftAll+countLeft<thresEachSide){
								attrValueFreq += m_ClassAttCounts[classVal][attIndex[att] - movepos] * (1.0/Math.pow(2.0, movepos));
								countLeftAll += countLeft;
							}
							else{
								attrValueFreq += m_ClassAttCounts[classVal][attIndex[att] - movepos] * ((thresEachSide-countLeftAll)/countLeft) * (1.0/Math.pow(2.0, movepos));
								countLeftAll += thresEachSide-countLeftAll;
							}
							movepos++;
							
						}
						
						double countRightAll = 0;
						movepos = 1;
						while(countRightAll<thresEachSide && (int) instance.value(att) + movepos < instance.attribute(att).numValues()){
							double countRight = 0;
							if ((int) instance.value(att) + movepos < instance.attribute(att).numValues()) {
								for (int class1 = 0; class1 < m_NumClasses; class1++) {
									countRight += m_ClassAttCounts[class1][attIndex[att] + movepos];
								}
							}
							
							if(countRightAll+countRight<thresEachSide){
								attrValueFreq += m_ClassAttCounts[classVal][attIndex[att] + movepos] * (1.0/Math.pow(2.0, movepos));
								countRightAll += countRight;
							}
							else{
								attrValueFreq += m_ClassAttCounts[classVal][attIndex[att] + movepos] * ((thresEachSide-countRightAll)/countRight) * (1.0/Math.pow(2.0, movepos));
								countRightAll += thresEachSide-countRightAll;
							}
							movepos++;
							
						}
						
					}

					double laplaceProb = (attrValueFreq+1.0/m_NumAttValues[att]) / (m_ClassCounts[classVal] + 1.0);
					probs[classVal] *= laplaceProb;
					

				}

				else{
					double laplaceProb = (m_ClassAttCounts[classVal][attIndex[att]] + 1.0/m_NumAttValues[att])
							/ (m_ClassCounts[classVal] + 1.0);
					probs[classVal] *= laplaceProb;
				}

				if (probs[classVal] > max) {
					max = probs[classVal];
				}

				if ((max > 0) && (max < 1e-75)) { // Danger of probability underflow
					for (int j = 0; j < m_NumClasses; j++) {
						probs[j] *= 1e75;
					}
				}
				
			}
			
		}
		
		Utils.normalize(probs);
		
		return probs;
	}

	/**
	 * Main method for testing this class.
	 *
	 * @param argv
	 *            the options
	 */
	public static void main(String[] argv) {
		try {
			System.out.println(Evaluation.evaluateModel(new RNDD(), argv));
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
	}

}
