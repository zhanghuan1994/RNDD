The detailed processes of using the code（WEKA 3.6.7）：
1、Put RNDD.java into directory: weka.classifiers.bayes
2、Put RNDDiscretize.java into directory: weka.filters.unsupervised.attribute
3、Add the code in calculateCutPointsByRNDD.txt into file: weka.filters.unsupervised.attribute.Discretize.java
2、Run WEKA, choose Experimenter/Explorer window, add the datasets, choose bayes.RNDD algorithm, then click "start". 